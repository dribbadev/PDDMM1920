//Juan de la cruz Hernandez Garcia

import UIKit

let whereIsWaldo = ["Whitebeard", "Wood", "Whitebeard", "Wilma", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Wilma", "Wilma", "Odlaw", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Whitebeard", "Whitebeard", "Wenda", "Wood", "Wood", "Wood", "Wilma", "Whitebeard", "Wilma", "Whitebeard", "Wenda", "Wenda", "Whitebeard", "Odlaw", "Odlaw", "Wenda", "Wenda", "Wood", "Whitebeard", "Whitebeard", "Odlaw", "Wilma", "Whitebeard", "Waldo", "Odlaw"]

/* Ex1. Implement a Where is Waldo algorithm.
    - Show the user the position of Waldo in the array.
    - Show the user how many of every characters are in the array (Sorted by number of appearances)
    - User for-in loops rather than regular for loops.
    - Structure the code as good as you can.
 */


//Dictionary
var count: [String: Int] = [String: Int]()
//Int for waldo position
var waldoPosition: Int = Int()

//Function to get index of string "Waldo" in the array and also create the dictionary
func getArrayInfo() {
    for (idx, element) in whereIsWaldo.enumerated() {
        if element == "Waldo" {
            waldoPosition = idx;
        }
        
        if count[element] == nil {
            count[element] = 1
        } else {
            count[element]! += 1
        }
    }
}

//Can sort an array with the sorted function of a dictionary in swift.
func sortArray() {
    //Element 0, el valor ha de ser superior al valor del element 1.
    let sortedArray = count.sorted{ $0.1 > $1.1 }
    print("New array is: ")
    for element in sortedArray {
        print(element)
    }
}

//Show waldo position
getArrayInfo()
print("Waldo position in array: \(waldoPosition)")

//Show new sorted array
sortArray()
