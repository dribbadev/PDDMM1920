// Programació de Dispositius Mòbils
// Nom: Lluís Masdeu
// Login: lluis.masdeu
// http://studyswift.blogspot.com/2017/05/how-to-sort-array-and-dictionary.html

import UIKit

let whereIsWaldo = ["Whitebeard", "Wood", "Whitebeard", "Wilma", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Wilma", "Wilma", "Odlaw", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Whitebeard", "Whitebeard", "Wenda", "Wood", "Wood", "Wood", "Wilma", "Whitebeard", "Wilma", "Whitebeard", "Wenda", "Wenda", "Whitebeard", "Odlaw", "Odlaw", "Wenda", "Wenda", "Wood", "Whitebeard", "Whitebeard", "Odlaw", "Wilma", "Whitebeard", "Waldo", "Odlaw"]

/* Ex1. Implement a Where is Waldo algorithm.
    - Show the user the position of Waldo in the array.
    - Show the user how many of every characters are in the array (Sorted by number of appearances)
    - Use for-in loops rather than regular for loops.
    - Structure the code as good as you can.
 */

var namesList = [String : Int]()
var i:Int = -1
var waldoPos = -1

for name in whereIsWaldo {
    i += 1
    
    if name == "Waldo" {
        waldoPos = i
    }

    if namesList[name] == nil {
        namesList[name] = 1
    } else {
        namesList[name]! += 1
    }
}

print("Waldo is at the position #\(waldoPos)!\n")
print("This are the characters in the array:")

for element in namesList {
    print("\(element.key) has appeared \(element.value) times!")
}

print("\nThis are the characters sorted in the array:")

let dictValInc = namesList.sorted(by: { $0.value > $1.value })

for element in dictValInc {
    print("\(element.key) has appeared \(element.value) times!")
}
