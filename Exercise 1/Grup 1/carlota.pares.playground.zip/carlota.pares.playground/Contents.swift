import UIKit

let whereIsWaldo = ["Whitebeard", "Wood", "Whitebeard", "Wilma", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Wilma", "Wilma", "Odlaw", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Whitebeard", "Whitebeard", "Wenda", "Wood", "Wood", "Wood", "Wilma", "Whitebeard", "Wilma", "Whitebeard", "Wenda", "Wenda", "Whitebeard", "Odlaw", "Odlaw", "Wenda", "Wenda", "Wood", "Whitebeard", "Whitebeard", "Odlaw", "Wilma", "Whitebeard", "Waldo", "Odlaw"]

/* Ex1. Implement a Where is Waldo algorithm.
    - Show the user the position of Waldo in the array.
    - Show the user how many of every characters are in the array (Sorted by number of appearances)
    - User for-in loops rather than regular for loops.
    - Structure the code as good as you can.
 */

/* Variables */
var charCountDict = [String: Int]()
var waldoPos: Int?

for (id, word) in whereIsWaldo.enumerated() {
    
    /* Store Waldo position */
    if word == "Waldo" {
        waldoPos = id
    }
    
    /* Check if key exists. If it does exist, increase value by 1, else, insert new key with a value of 1 */ 
    if let count = charCountDict[word] {
        charCountDict[word] = count + 1
    } else{
        charCountDict[word] = 1
    }
    
}

/* Sort dictionary by value */
let sortedDict = charCountDict.sorted(by: { $0.1 > $1.1 })

/* Print data */
if let idx = waldoPos {
    print("The position of Waldo is \(idx).\n")
} else{
    print("Ups! We couldn't find Waldo.\n")
}

print("The characters order is the following:\n")
for (key, val) in sortedDict {
    print("\(key): \(val)")
}

