import UIKit

let whereIsWaldo = ["Whitebeard", "Wood", "Whitebeard", "Wilma", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Wilma", "Wilma", "Odlaw", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Whitebeard", "Whitebeard", "Wenda", "Wood", "Wood", "Wood", "Wilma", "Whitebeard", "Wilma", "Whitebeard", "Wenda", "Wenda", "Whitebeard", "Odlaw", "Odlaw", "Wenda", "Wenda", "Wood", "Whitebeard", "Whitebeard", "Odlaw", "Wilma", "Whitebeard", "Waldo", "Odlaw"]

/* Ex1. Implement a Where is Waldo algorithm.
    - Show the user the position of Waldo in the array.
    - Show the user how many of every characters are in the array (Sorted by number of appearances)
    - User for-in loops rather than regular for loops.
    - Structure the code as good as you can.
 */

func findWaldo() -> Void{
    var waldoPos : Int = -1
    var counterArr : [String:Int] = [String:Int]()
    for (i, name) in whereIsWaldo.enumerated() {
        if name == "Waldo" {
            waldoPos = i
        }
        
        if counterArr[name] != nil {
            counterArr[name]! += 1
        } else {
            counterArr[name] = 1
        }
    }
    let counterArrDec = counterArr.sorted(by: { $0.value > $1.value })
    
    print(waldoPos)
    print(counterArrDec)
}

findWaldo()
