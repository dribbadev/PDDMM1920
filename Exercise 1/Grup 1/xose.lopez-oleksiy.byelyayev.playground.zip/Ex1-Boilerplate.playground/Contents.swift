import UIKit

let whereIsWaldo = ["Whitebeard", "Wood", "Whitebeard", "Wilma", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Wilma", "Wilma", "Odlaw", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Whitebeard", "Whitebeard", "Wenda", "Wood", "Wood", "Wood", "Wilma", "Whitebeard", "Wilma", "Whitebeard", "Wenda", "Wenda", "Whitebeard", "Odlaw", "Odlaw", "Wenda", "Wenda", "Wood", "Whitebeard", "Whitebeard", "Odlaw", "Wilma", "Whitebeard", "Waldo", "Odlaw"]

func fWhereIsWaldo(whereIsWaldo:Array<String>) -> Int {
    
    for (idx, person) in whereIsWaldo.enumerated(){
        if person == "Waldo" {
            return idx
        }
    }
    
    return -1
}

func createDictionary(whereIsWaldo:Array<String>) -> [String:Int] {
    var apariciones = [String:Int]()
    
    for person in whereIsWaldo{
        if let name=apariciones[person]{
            // Has already been found previously
            apariciones[person]! += 1
        }else{
            // First time
            apariciones[person] = 1
        }
    }
    
    return apariciones
}

func howManyTimesEachOne(appearances:[String:Int]) -> [(key:String,value:Int)] {
    return appearances.sorted{$0.1 > $1.1}
}



// Execute this
print("Waldo is in this position: " + String(fWhereIsWaldo(whereIsWaldo: whereIsWaldo)))
print()

var appearances = createDictionary(whereIsWaldo: whereIsWaldo)
print("Order of appearances: ")
let sortedArray = howManyTimesEachOne(appearances: appearances)
for element in sortedArray{
    print("\(element.key) - \(element.value) times")
}


/* Ex1. Implement a Where is Waldo algorithm.
    - Show the user the position of Waldo in the array.
    - Show the user how many of every characters are in the array (Sorted by number of appearances)
    - User for-in loops rather than regular for loops.
    - Structure the code as good as you can.
 */
