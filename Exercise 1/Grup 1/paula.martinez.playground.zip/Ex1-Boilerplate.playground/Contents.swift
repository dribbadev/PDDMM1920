import UIKit

let whereIsWaldo = ["Whitebeard", "Wood", "Whitebeard", "Wilma", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Wilma", "Wilma", "Odlaw", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Whitebeard", "Whitebeard", "Wenda", "Wood", "Wood", "Wood", "Wilma", "Whitebeard", "Wilma", "Whitebeard", "Wenda", "Wenda", "Whitebeard", "Odlaw", "Odlaw", "Wenda", "Wenda", "Wood", "Whitebeard", "Whitebeard", "Odlaw", "Wilma", "Whitebeard", "Waldo", "Odlaw"]

var characters = [String:Int]()

/* Ex1. Implement a Where is Waldo algorithm.
    - Show the user the position of Waldo in the array.
    - Show the user how many of every characters are in the array (Sorted by number of appearances)
    - User for-in loops rather than regular for loops.
    - Structure the code as good as you can.
 */

for (idx, element) in whereIsWaldo.enumerated() {
    if element == "Waldo" {
        print ("Index: \(idx)")
    }
    
    if characters[element] == nil {
        characters[element] = 1
    } else {
        characters[element]! += 1
    }
}

let sortedDictionary = characters.sorted{ $0.1 > $1.1 }

for (idx1, element1) in sortedDictionary.enumerated() {
    print("Paraula: \(idx1) aparicions: \(element1)")
}

