import UIKit

let whereIsWaldo = ["Whitebeard", "Wood", "Whitebeard", "Wilma", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Wilma", "Wilma", "Odlaw", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Whitebeard", "Whitebeard", "Wenda", "Wood", "Wood", "Wood", "Wilma", "Whitebeard", "Wilma", "Whitebeard", "Wenda", "Wenda", "Whitebeard", "Odlaw", "Odlaw", "Wenda", "Wenda", "Wood", "Whitebeard", "Whitebeard", "Odlaw", "Wilma", "Whitebeard", "Waldo", "Odlaw"]

let compare = "Wenda";

var appearances = [String:Int]();

for (idx,element) in whereIsWaldo.enumerated(){
    if(element == compare){
        print("\(compare) found at position \(idx)");
    }
    if let data=appearances[element]{
        appearances[element]! += 1;
    }
    else{
        appearances[element] = 1;
    }
}

let sortedByValue = appearances.sorted{ $0.1 > $1.1 };
print()
for element in sortedByValue{
    print("\(element.key) a aparecido \(element.value)")
}

/* Ex1. Implement a Where is Waldo algorithm.
    - Show the user the position of Waldo in the array.
    - Show the user how many of every characters are in the array (Sorted by number of appearances)
    - User for-in loops rather than regular for loops.
    - Structure the code as good as you can.
 */
//alex@dribba.com