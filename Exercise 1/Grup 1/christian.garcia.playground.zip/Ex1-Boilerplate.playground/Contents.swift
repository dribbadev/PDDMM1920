import UIKit

let whereIsWaldo = ["Whitebeard", "Wood", "Whitebeard", "Wilma", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Wilma", "Wilma", "Odlaw", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Whitebeard", "Whitebeard", "Wenda", "Wood", "Wood", "Wood", "Wilma", "Whitebeard", "Wilma", "Whitebeard", "Wenda", "Wenda", "Whitebeard", "Odlaw", "Odlaw", "Wenda", "Wenda", "Wood", "Whitebeard", "Whitebeard", "Odlaw", "Wilma", "Whitebeard", "Waldo", "Odlaw"]

/* Ex1. Implement a Where is Waldo algorithm.
    - Show the user the position of Waldo in the array.
    - Show the user how many of every characters are in the array (Sorted by number of appearances)
    - User for-in loops rather than regular for loops.
    - Structure the code as good as you can.
 */

//1
func getWaldoIndex() -> Int {
    var i: Int = -1;
    for (index, name) in whereIsWaldo.enumerated() {
        if name == "Waldo" {
            i = index;
        }
    }
    return i;
}
print(getWaldoIndex());

//2
func getCharacters() -> [String:Int] {
    
    var chars: [String:Int] = [String:Int]();

    for name in whereIsWaldo {
        if (chars[name] == nil) {
            chars[name] = 1;
        } else {
            chars[name]! += 1;
        }
    }
    
    return chars;
    
}
var allChars: [String:Int] = getCharacters();
for (name, times) in allChars {
    print("\(name) repeats \(times)\n");
}

//3
var sortedChars = allChars.sorted{$0.value > $1.value};
print(sortedChars);
