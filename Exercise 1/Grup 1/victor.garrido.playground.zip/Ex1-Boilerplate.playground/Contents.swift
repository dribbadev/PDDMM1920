
import UIKit

let whereIsWaldo = ["Whitebeard", "Wood", "Whitebeard", "Wilma", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Wilma", "Wilma", "Odlaw", "Wilma", "Wood", "Whitebeard", "Whitebeard", "Whitebeard", "Whitebeard", "Wenda", "Wood", "Wood", "Wood", "Wilma", "Whitebeard", "Wilma", "Whitebeard", "Wenda", "Wenda", "Whitebeard", "Odlaw", "Odlaw", "Wenda", "Wenda", "Wood", "Whitebeard", "Whitebeard", "Odlaw", "Wilma", "Whitebeard", "Waldo", "Odlaw"]



/* Ex1. Implement a Where is Waldo algorithm.
    - Show the user the position of Waldo in the array.
    - Show the user how many of every characters are in the array (Sorted by number of appearances)
    - User for-in loops rather than regular for loops.
    - Structure the code as good as you can.
 */
var diccionari: [String : Int] = [String : Int]()

// TODO: Optimize with Optional Binding
for (index,name) in whereIsWaldo.enumerated(){
    if name == "Waldo"
    {
        print("Waldo is in " , index)
    }
    
    if diccionari[name] == nil
    {
        diccionari[name] = 1
    }else
    {
        diccionari[name]! += 1
    }
    
    /*
    if let character = diccionari[name] {
        diccionari[name]! += 1

    }*/
    
    
}

let sortedDictionary = diccionari.sorted{ $0.value > $1.value}
for element in sortedDictionary{
    print("L'element",element.key, "te", element.value, "aparaicons" )
}



